package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

@SpringBootApplication
public class SslServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SslServerApplication.class, args);
	}

}

@RestController
class ServerController{

	public static String calculateHash(String name) throws NoSuchAlgorithmException {  
        // Static getInstance method is called with hashing SHA 
        MessageDigest md = MessageDigest.getInstance("SHA-256"); 

        // digest() method called 
        // to calculate message digest of an input 
        // and return array of byte 
        byte[] encodedhash = md.digest(name.getBytes(StandardCharsets.UTF_8));
        
        // Convert bytes to hex
        StringBuilder hexString = new StringBuilder(2 * encodedhash.length);
        for (int i = 0; i < encodedhash.length; i++) {
            String hex = Integer.toHexString(0xff & encodedhash[i]);
            if(hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
	}
       
	
@RequestMapping("/hash")
public String myHash() throws NoSuchAlgorithmException{

	String data = "Elizabeth Hodgman";
	String hash = calculateHash(data);

	return "<p>data: " + data + "</p><p> Name of Cipher Algorithm Used: SHA-256 Value: " + hash;

}
}